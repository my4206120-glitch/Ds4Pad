package com.mohammad.ds4test;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Ds4Pad: يجعل الجوال قبضة بلوتوث كاملة لـPS4 */
public class MainActivity extends Activity {

    /** وصف قبضة من تصميمي: 16 زراً، وأزرار اتجاه (hat)، و6 محاور بقيمة 0 إلى 255 */
    static final byte[] DESCRIPTOR = {
            0x05, 0x01, 0x09, 0x05, (byte) 0xA1, 0x01,            // Gamepad / Application
            0x05, 0x09, 0x19, 0x01, 0x29, 0x10,                   // Buttons 1..16
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, (byte) 0x95, 0x10,
            (byte) 0x81, 0x02,
            0x05, 0x01, 0x09, 0x39,                               // Hat switch
            0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
            0x75, 0x04, (byte) 0x95, 0x01, (byte) 0x81, 0x42,     // with null state
            0x75, 0x04, (byte) 0x95, 0x01, (byte) 0x81, 0x01,     // padding
            0x09, 0x30, 0x09, 0x31, 0x09, 0x33, 0x09, 0x34,       // X, Y, Rx, Ry
            0x09, 0x32, 0x09, 0x35,                               // Z, Rz (triggers)
            0x15, 0x00, 0x26, (byte) 0xFF, 0x00,
            0x75, 0x08, (byte) 0x95, 0x06, (byte) 0x81, 0x02,
            (byte) 0xC0
    };

    // أرقام الأزرار (بت في التقرير)
    static final int B_X = 1 << 0, B_O = 1 << 1, B_TRI = 1 << 2, B_SQ = 1 << 3,
            B_L1 = 1 << 4, B_R1 = 1 << 5, B_L2D = 1 << 6, B_R2D = 1 << 7,
            B_SHARE = 1 << 8, B_OPTIONS = 1 << 9, B_L3 = 1 << 10, B_R3 = 1 << 11, B_PS = 1 << 12;

    static final int BLUE = 0xFF2D6BFF, RED = 0xFFE04C5C, GREEN = 0xFF2BB673, PINK = 0xFFD86CB3,
            DARK = 0xFF1B2230, DARK2 = 0xFF121826, TEXT = 0xFFEAF0FF;

    BluetoothAdapter adapter;
    BluetoothHidDevice hid;
    BluetoothDevice host;
    TextView status;
    final Handler h = new Handler(Looper.getMainLooper());

    int buttons = 0;
    boolean up, down, left, right;
    int lx = 128, ly = 128, rx = 128, ry = 128, l2 = 0, r2 = 0;

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));
        root.setBackgroundColor(DARK2);

        // ---- الرأس ----
        LinearLayout head = row();
        status = new TextView(this);
        status.setTextColor(TEXT);
        status.setTextSize(14);
        status.setText("جارٍ التحضير...");
        head.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        Button reg = smallBtn("تشغيل", BLUE);
        reg.setOnClickListener(v -> register());
        head.addView(reg);
        Button disc = smallBtn("ظهور", GREEN);
        disc.setOnClickListener(v -> makeDiscoverable());
        head.addView(disc);
        root.addView(head, matchWrap(0));

        // ---- الأزرار العلوية: L2 L1 | R1 R2 ----
        LinearLayout shoulders = row();
        shoulders.addView(trigger("L2", true), weight(1));
        shoulders.addView(bindBtn("L1", B_L1, DARK, TEXT), weight(1));
        shoulders.addView(bindBtn("R1", B_R1, DARK, TEXT), weight(1));
        shoulders.addView(trigger("R2", false), weight(1));
        root.addView(shoulders, matchWrap(8));

        // ---- الاتجاهات | الوسط | الأزرار ----
        LinearLayout mid = row();
        mid.addView(dpad(), weight(1));
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.addView(bindBtn("Share", B_SHARE, DARK, TEXT), matchWrap(0));
        center.addView(bindBtn("PS", B_PS, DARK, TEXT), matchWrap(6));
        center.addView(bindBtn("Options", B_OPTIONS, DARK, TEXT), matchWrap(6));
        mid.addView(center, weight(1));
        mid.addView(faceButtons(), weight(1));
        root.addView(mid, matchWrap(8));

        // ---- العصوان مع L3 و R3 ----
        LinearLayout sticks = row();
        sticks.addView(stickBlock("L3", B_L3, true), weight(1));
        sticks.addView(stickBlock("R3", B_R3, false), weight(1));
        root.addView(sticks, matchWrap(8));

        setContentView(root);
        setupBluetooth();
    }

    // ================= البلوتوث =================

    void setupBluetooth() {
        adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            status.setText("لا يوجد بلوتوث في هذا الجوال");
            return;
        }
        if (Build.VERSION.SDK_INT < 28) {
            status.setText("يحتاج الجوال أندرويد 9 أو أحدث");
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE}, 1);
        }
        adapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override
            public void onServiceConnected(int profile, BluetoothProfile proxy) {
                hid = (BluetoothHidDevice) proxy;
                status.setText("جاهز، اضغط تشغيل");
            }

            @Override
            public void onServiceDisconnected(int profile) {
                hid = null;
                status.setText("انقطع الملف الشخصي للبلوتوث");
            }
        }, BluetoothProfile.HID_DEVICE);
    }

    void register() {
        if (hid == null) {
            Toast.makeText(this, "الملف الشخصي غير جاهز بعد", Toast.LENGTH_SHORT).show();
            return;
        }
        BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings(
                "Ds4Pad", "Gamepad", "Mohammad", (byte) 0x08, DESCRIPTOR);
        hid.registerApp(sdp, null, null, getMainExecutor(), new BluetoothHidDevice.Callback() {
            @Override
            public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean registered) {
                status.setText(registered ? "مسجّل كقبضة، اضغط ظهور" : "لم يُسجّل بعد");
            }

            @Override
            public void onConnectionStateChanged(BluetoothDevice device, int state) {
                if (state == BluetoothProfile.STATE_CONNECTED) {
                    host = device;
                    status.setText("متصل بـ: " + device.getName());
                } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                    host = null;
                    status.setText("انقطع الاتصال، اضغط ظهور ثم اقترن من PS4");
                }
            }
        });
    }

    void makeDiscoverable() {
        Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120);
        startActivity(i);
    }

    /** يحسب قيمة الاتجاه (hat) من الأزرار المضغوطة */
    int hatValue() {
        if (up && right) return 1;
        if (right && down) return 3;
        if (down && left) return 5;
        if (left && up) return 7;
        if (up) return 0;
        if (right) return 2;
        if (down) return 4;
        if (left) return 6;
        return 8; // لا شيء مضغوط
    }

    void sendState() {
        if (hid == null || host == null) return;
        byte[] r = new byte[9];
        r[0] = (byte) (buttons & 0xFF);
        r[1] = (byte) ((buttons >> 8) & 0xFF);
        r[2] = (byte) (hatValue() & 0x0F);
        r[3] = (byte) lx;
        r[4] = (byte) ly;
        r[5] = (byte) rx;
        r[6] = (byte) ry;
        r[7] = (byte) l2;
        r[8] = (byte) r2;
        hid.sendReport(host, 0, r);
    }

    // ================= عناصر التحكم =================

    /** زر عادي: يضبط بت الزر عند الضغط ويمسحه عند الرفع */
    Button bindBtn(String label, final int bit, int fill, int ink) {
        Button b = smallBtn(label, fill);
        b.setTextColor(ink);
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
                buttons |= bit;
                v.setAlpha(0.6f);
                sendState();
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL || a == MotionEvent.ACTION_POINTER_UP) {
                buttons &= ~bit;
                v.setAlpha(1f);
                sendState();
                return true;
            }
            return true;
        });
        return b;
    }

    /** الزناد L2 أو R2: تحريك تناظري (0 إلى 255) مع الزر الرقمي */
    Button trigger(String label, final boolean left2) {
        Button b = smallBtn(label, DARK);
        final int digital = left2 ? B_L2D : B_R2D;
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            boolean pressed = a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN;
            boolean released = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL || a == MotionEvent.ACTION_POINTER_UP;
            if (pressed) {
                if (left2) l2 = 255; else r2 = 255;
                buttons |= digital;
                v.setAlpha(0.6f);
                sendState();
            } else if (released) {
                if (left2) l2 = 0; else r2 = 0;
                buttons &= ~digital;
                v.setAlpha(1f);
                sendState();
            }
            return true;
        });
        return b;
    }

    /** لوحة الاتجاهات: تشغّل أزرار hat بحسب الاتجاه المضغوط */
    LinearLayout dpad() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.addView(dirBtn("▲", 0), matchWrap(0));
        LinearLayout mid = row();
        mid.addView(dirBtn("◀", 1), weight(1));
        mid.addView(spacer(), weight(1));
        mid.addView(dirBtn("▶", 2), weight(1));
        col.addView(mid, matchWrap(4));
        col.addView(dirBtn("▼", 3), matchWrap(4));
        return col;
    }

    Button dirBtn(String label, final int dir) {
        Button b = smallBtn(label, DARK);
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            boolean pressed = a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN;
            boolean released = a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL || a == MotionEvent.ACTION_POINTER_UP;
            if (pressed || released) {
                boolean on = pressed;
                if (dir == 0) up = on;
                if (dir == 1) left = on;
                if (dir == 2) right = on;
                if (dir == 3) down = on;
                v.setAlpha(on ? 0.6f : 1f);
                sendState();
            }
            return true;
        });
        return b;
    }

    /** أزرار الوجه: △ فوق، ◀ □ يسار، ▶ ○ يمين، × تحت */
    LinearLayout faceButtons() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.addView(bindBtn("△", B_TRI, PINK, TEXT), matchWrap(0));
        LinearLayout mid = row();
        mid.addView(bindBtn("□", B_SQ, BLUE, TEXT), weight(1));
        mid.addView(spacer(), weight(1));
        mid.addView(bindBtn("○", B_O, RED, TEXT), weight(1));
        col.addView(mid, matchWrap(4));
        col.addView(bindBtn("×", B_X, GREEN, TEXT), matchWrap(4));
        return col;
    }

    /** عصا تناظرية تُسحب باللمس، مع زر النقر عليها */
    LinearLayout stickBlock(String label, final int clickBit, final boolean isLeft) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        Stick s = new Stick(this);
        s.onMove = (x, y) -> {
            if (isLeft) { lx = x; ly = y; } else { rx = x; ry = y; }
            sendState();
        };
        c.addView(s, new LinearLayout.LayoutParams(dp(150), dp(150)));
        c.addView(bindBtn(label, clickBit, DARK, TEXT), matchWrap(4));
        return c;
    }

    /** عصا تناظرية داخل دائرة */
    static class Stick extends View {
        interface OnMove { void on(int x, int y); }
        OnMove onMove;
        float px = 0, py = 0; // بين -1 و1
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        Stick(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f, r = Math.min(w, h) / 2f - 4;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF1B2230);
            c.drawCircle(cx, cy, r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(3);
            p.setColor(0x6600F0FF);
            c.drawCircle(cx, cy, r, p);
            float kx = cx + px * (r * 0.6f), ky = cy + py * (r * 0.6f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF2D6BFF);
            c.drawCircle(kx, ky, r * 0.32f, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                px = 0;
                py = 0;
                invalidate();
                emit(128, 128);
                return true;
            }
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - 4;
            float dx = (e.getX() - w / 2f) / (r * 0.6f);
            float dy = (e.getY() - h / 2f) / (r * 0.6f);
            double m = Math.sqrt(dx * dx + dy * dy);
            if (m > 1) { dx /= m; dy /= m; }
            px = dx;
            py = dy;
            invalidate();
            int x = Math.round(128 + dx * 127);
            int y = Math.round(128 + dy * 127);
            emit(x, y);
            return true;
        }

        void emit(int x, int y) {
            if (onMove != null) onMove.on(Math.max(0, Math.min(255, x)), Math.max(0, Math.min(255, y)));
        }
    }

    // ================= أدوات الواجهة =================

    Button smallBtn(String label, int fill) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTextSize(14);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setMinHeight(dp(44));
        b.setMinimumHeight(dp(44));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(p);
        return b;
    }

    View spacer() {
        return new View(this);
    }

    LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        return r;
    }

    LinearLayout.LayoutParams matchWrap(int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(topDp), 0, 0);
        return p;
    }

    LinearLayout.LayoutParams weight(float w) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, w);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        return p;
    }

    @Override
    protected void onDestroy() {
        try {
            if (hid != null) hid.unregisterApp();
        } catch (Exception ignored) { }
        super.onDestroy();
    }
}
