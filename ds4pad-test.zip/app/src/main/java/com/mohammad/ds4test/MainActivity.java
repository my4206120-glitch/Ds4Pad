package com.mohammad.ds4test;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** اختبار: هل يستطيع الجوال أن يظهر كقبضة بلوتوث ويرسل ضغطة إلى PS4 */
public class MainActivity extends Activity {

    /** وصف قبضة عام بسيط: 16 زراً و4 محاور، بدون معرّف تقرير */
    static final byte[] DESCRIPTOR = {
            0x05, 0x01,             // Usage Page: Generic Desktop
            0x09, 0x05,             // Usage: Gamepad
            (byte) 0xA1, 0x01,      // Collection: Application
            0x05, 0x09,             // Usage Page: Button
            0x19, 0x01,             // Usage Minimum: 1
            0x29, 0x10,             // Usage Maximum: 16
            0x15, 0x00,             // Logical Minimum: 0
            0x25, 0x01,             // Logical Maximum: 1
            0x75, 0x01,             // Report Size: 1
            (byte) 0x95, (byte) 0x10,             // Report Count: 16
            (byte) 0x81, 0x02,      // Input: Data, Variable, Absolute
            0x05, 0x01,             // Usage Page: Generic Desktop
            0x09, 0x30,             // Usage: X
            0x09, 0x31,             // Usage: Y
            0x09, 0x32,             // Usage: Z
            0x09, 0x35,             // Usage: Rz
            0x15, 0x00,             // Logical Minimum: 0
            0x26, (byte) 0xFF, 0x00, // Logical Maximum: 255
            0x75, 0x08,             // Report Size: 8
            (byte) 0x95, (byte) 0x04,             // Report Count: 4
            (byte) 0x81, 0x02,      // Input: Data, Variable, Absolute
            (byte) 0xC0             // End Collection
    };

    BluetoothAdapter adapter;
    BluetoothHidDevice hid;
    BluetoothDevice host;
    TextView status;
    final Handler h = new Handler(Looper.getMainLooper());

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        status = new TextView(this);
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setText("جارٍ التحضير...");
        root.addView(status);

        Button reg = button("1) تسجيل الجوال كقبضة");
        reg.setOnClickListener(v -> register());
        root.addView(reg);

        Button pair = button("2) إظهار الجوال للـPS4");
        pair.setOnClickListener(v -> makeDiscoverable());
        root.addView(pair);

        Button press = button("3) إرسال ضغطة X");
        press.setOnClickListener(v -> pressX());
        root.addView(press);

        setContentView(root);

        adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            status.setText("هذا الجوال لا يحتوي بلوتوث");
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE}, 1);
        }
        if (Build.VERSION.SDK_INT < 28) {
            status.setText("يحتاج الجوال أندرويد 9 أو أحدث");
            return;
        }
        adapter.getProfileProxy(this, new BluetoothProfile.ServiceListener() {
            @Override
            public void onServiceConnected(int profile, BluetoothProfile proxy) {
                hid = (BluetoothHidDevice) proxy;
                status.setText("الملف الشخصي جاهز، اضغط الزر 1");
            }

            @Override
            public void onServiceDisconnected(int profile) {
                hid = null;
                status.setText("انقطع الملف الشخصي");
            }
        }, BluetoothProfile.HID_DEVICE);
    }

    Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(p);
        return b;
    }

    void register() {
        if (hid == null) {
            Toast.makeText(this, "الملف الشخصي غير جاهز بعد", Toast.LENGTH_SHORT).show();
            return;
        }
        BluetoothHidDeviceAppSdpSettings sdp = new BluetoothHidDeviceAppSdpSettings(
                "Ds4Test", "Gamepad test", "Mohammad", (byte) 0x08, DESCRIPTOR);
        hid.registerApp(sdp, null, null, getMainExecutor(), new BluetoothHidDevice.Callback() {
            @Override
            public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean registered) {
                status.setText(registered ? "مسجّل كقبضة، اضغط الزر 2" : "لم يُسجّل بعد");
            }

            @Override
            public void onConnectionStateChanged(BluetoothDevice device, int state) {
                if (state == BluetoothProfile.STATE_CONNECTED) {
                    host = device;
                    status.setText("متصل بـ: " + device.getName());
                } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                    host = null;
                    status.setText("انقطع الاتصال، أعد الزر 2");
                }
            }
        });
    }

    void makeDiscoverable() {
        Intent i = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120);
        startActivity(i);
    }

    void pressX() {
        if (hid == null || host == null) {
            Toast.makeText(this, "لا يوجد اتصال مع PS4 بعد", Toast.LENGTH_SHORT).show();
            return;
        }
        sendMask(0x0001);
        h.postDelayed(() -> sendMask(0x0000), 120);
    }

    void sendMask(int mask) {
        byte[] r = {(byte) (mask & 0xFF), (byte) ((mask >> 8) & 0xFF), 0, 0, 0, 0};
        hid.sendReport(host, 0, r);
    }

    @Override
    protected void onDestroy() {
        try {
            if (hid != null) hid.unregisterApp();
        } catch (Exception ignored) { }
        super.onDestroy();
    }
}
